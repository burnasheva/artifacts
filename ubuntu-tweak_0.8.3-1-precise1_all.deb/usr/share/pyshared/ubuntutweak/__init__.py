VERSION = (0, 8, 3)
__version__ = '.'.join(map(str, VERSION))
